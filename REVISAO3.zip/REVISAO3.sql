create database PetShop;
use PetShop;
 
create table Animal (
Id_Animal int auto_increment primary key,
Nome_Animal varchar (30) not null,
Raca_Especie int references Especie (Raca_Especie) 
);

create table Especie (
Id_Animal int references Animal (Id_Animal),
Nome_Especie varchar (20) not null,
Raca_Espécie int auto_increment primary key
);

rename table Especie to Raca;

create table Dono (
Id_Dono int auto_increment primary key,
Nome_Dono varchar (30) not null,
CPF_Dono varchar (11) unique,
Fone varchar (20)
); 

alter table Animal add Dono int;
alter table Animal add foreign key (Dono) references Dono (Id_Dono);
select distinct CPF_Dono from Dono;

insert into Animal (
Nome_Animal,
Raca_Especie
)
Values
('Toto','1'),
('Toto','2'),
('Lica','1'),
('Brutus','3'),
('Pluto','1');

insert into Raca (
Id_Animal,
Nome_Especie
)
Values
('1','Vira-lata'),
('2','Poodle');

insert into Dono (
Nome_Dono,
CPF_Dono,
Fone
)
Values
('João','1234','3333 4444'),
('Pedro','5678','3333 5555'),
('José','9123','3333 6666'),
('Maria','4321','3333 2222');

update
	Animal
set
	Nome_Animal = 'Rex'
where
	Id_Animal = 4;

delete from Animal where Id_Animal = 2;
update Animal set Dono = '4' where Id_Animal = '3';

create table Consulta (
Id_Consulta int auto_increment primary key,
Data_Consulta datetime,
Animal int references Animal (Id_Animal));

alter table Consulta add Horario time;

update Animal set Dono = '2' where id_Animal = '1';
update Animal set Dono = '3' where id_Animal = '2';
update Animal set Dono = '1' where id_Animal = '3';
update Animal set Dono = '1' where id_Animal = '4';
update Animal set Dono = '1' where id_Animal = '5';

insert into Consulta (
Data_Consulta,
Animal,
Horario)
Values
('20070112','1', '070000'),
('20070112','3', '080000'),
('20070113', '1', '070000');

delete from Consulta where Id_Consulta = '1';
update Consulta set Data_Consulta = '20070113' where Id_Consulta = '2';

