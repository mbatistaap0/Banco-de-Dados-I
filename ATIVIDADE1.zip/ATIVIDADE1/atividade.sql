create database Telecomunicações;
use Telecomunicações;
create table Cliente (
NomeCliente varchar(100),
CPFCliente varchar(12),
DataNascimentoCliente datetime,
EnderecoCliente varchar(50),
CEPCliente varchar (20),
BairroCliente varchar (30),
CidadeCliente varchar (40),
UFCliente varchar (2)
);
alter table Cliente add DataCompraCliente int auto_increment primary key;

insert into Cliente (
NomeCliente,
CPFCliente,
DataNascimentoCliente,
EnderecoCliente,
CEPCliente,
BairroCliente,
CidadeCliente,
UFCliente
)
values 
("João da Silva", "04496332780", "1969-11-25", "Rua Antônio Nunes", "88045963", "Palmeiras","Londrina","PR"),
("Ana Regina Fagundes", "054850314905", "1986-09-21", "Ruas Palmeias Novas", "88078923", "Leblon","Rio de Janeiro","RJ"),
("Fernando Soares", "03350314905", "1990-03-05", "Rua Palmeiras Novas", "88048917", "Copacabana","Rio de Janeiro","RJ");

select*from cliente where CidadeCliente = "Rio de Janeiro";
delete from cliente where CidadeCliente= "Londrina";