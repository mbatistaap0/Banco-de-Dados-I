create database Livraria;
use Livraria;

create table Clientes(
Codigo_Cliente int auto_increment primary key,
Telefone_Cliente varchar (11),
Endereço_Cliente varchar (45),
CPF_Cliente varchar(11) unique not null,
CNPJ_Cliente varchar(16) unique not null,
Livros_Comprados varchar (120),
Data_Livro_Comprados datetime,
Tipo_Cliente varchar (20));

create table Livros (
ISBN int auto_increment primary key,
Qtde int,
Assunto varchar (50),
Autor varchar (40),
Codigo_Editora int references Codigo_Editora (Editora),
Estoque int); 

create table Editora (
Codigo_Editora int auto_increment primary key,
Endereço_Editora varchar (30),
Telefone_Editora varchar (11),
Gerente_Editora varchar (40));

create table Cliente_compra_livros (
Codigo_Cliente int references Codigo_Cliente (Clientes),
ISBN int references ISNB(Livros),
Data_Livro_Comprados int references Data_Livro_Comprados(Clientes));

insert into Clientes (
Telefone_Cliente,
Endereço_Cliente,
CPF_Cliente,
CNPJ_Cliente,
Livros_Comprados,
Data_Livro_Comprados,
Tipo_Cliente)
values
('12996548719', 'Rua das Margaridas Finas', '36548774558', '45878549612', 'Sem Amor', '20190220', 'Estudante');

insert into Livros (
Qtde,
Assunto, 
Autor,
Codigo_Editora,
Estoque)
values
('2','Ficção','J.K Rowling',5,200);

insert into Editora (
Endereço_Editora,
Telefone_Editora,
Gerente_Editora)
values
('Avenida Paulista', '11569472531', 'Junior da Silva');

insert into Cliente_compra_livros (
Codigo_Cliente, 
ISBN,
Data_Livro_Comprados)
values
('1', '555555555', '20210309');

select * from Clientes;
select * from Livros;
select * from Editora;
select * from Cliente_compra_livros;


