create database Universidade;
use Universidade;

create table Departamento (
Nome_Departamento varchar (30), 
Codigo_Departamento int auto_increment primary key,
Telefone_Departamento varchar (11),
Centro_Departamento varchar (15)
);

create table Aluno (
Nome_Aluno varchar (30) not null,
Numero_de_Matricula int auto_increment primary key,
CPF_Aluno varchar (11) not null,
Endereco_Aluno varchar (100) not null,
Telefone_Aluno varchar (11) not null,
Telefone_Opcional varchar (11),
Data_Nascimento datetime not null,
Sexo_Aluno varchar (9) ,
Codigo_Departamento int references Departamento (Codigo_Departamento),
Curso int references Curso (Numero_Curso)
);

create table Curso (
Nome_Curso varchar (40),
Tipo_Curso varchar (11),
Codigo_Departamento int references Departamento (Codigo_Departamento),
Coordenador_Curso varchar (30),
Vice_coordenador_Curso varchar (30),
Numero_Curso int auto_increment primary key
);

create table Professor (
Matricula_Professor int auto_increment primary key,
Nome_Professor varchar (40),
CPF_Professor varchar (11),
Codigo_Departamento int references Departamento (Codigo_Departamento),
Telefone_Professor varchar (11),
Disciplina int references Disciplina (Codigo_Disciplina)
);

create table Disciplina (
Nome_Disciplina varchar (40),
Descricao_Disciplina varchar (70),
Codigo_Disciplina int auto_increment primary key,
Numero_Creditos varchar (2),
Codigo_Departamento int references Departamento (Codigo_Departamento),
Aluno int references Aluno (Numero_Matricula),
Professor int references Professor (Matricula_Professor),
Oferta int references Oferta (Codigo_Oferta)
);

create table Oferta (
Codigo_Oferta int auto_increment primary key,
Professor int references Professor (Matricula_Professor),
Horario_Entrada time, 
Horario_Saida time, 
Disciplina int references Disciplinas (Codigo_Disciplina),
Aluno int references Aluno (Numero_de_Matricula)
);

insert into Departamento (
Nome_Departamento,
Telefone_Departamento,
Centro_Departamento
)
values
('Marketing','11996544874','Academica'),
('Financeiro','11965588786','Educacional'),
('Recursos Humanos','11945785540','Educação'),
('Administração','11998784452','Academia'),
('Jurídico','12996554862','Academico');

insert into Aluno (
Nome_Aluno ,
CPF_Aluno,
Endereco_Aluno,
Telefone_Aluno,
Telefone_Opcional,
Data_Nascimento,
Sexo_Aluno,
Codigo_Departamento,
Curso)
Values
('Agatha Valentine','25445152332','Rua das Rosas, São José do Rio Preto, 12232200','12996544117','','20061110','F','1','3'),
('Hiago Ricardo','32554154878','Rua Campos Floridos, São Peregrino, 12232900','11332988441','12996021447','20000120','M','1','2'),
('Sarah Silva Castro','45887445569','Rua Sapos de Argila, Maranhão, 12322100','12336985684','','20000601','F','3','1'),
('Hugo Bento de Almeida','25445885447','Rua Campos Sales, Sergipe, 1123210','12995456201','11366241472','19990110','M','2','3'),
('Geraldo Fábio Junior','35411254774','Rua Jorge Cristo, Roraima, 12998765','11339652207','12994586225','19910217','M','1','4');

insert into Curso (
Nome_Curso,
Tipo_Curso,
Codigo_Departamento,
Coordenador_Curso,
Vice_coordenador_Curso
)
Values
('Desenvolvimento de Sistemas','Técnico','1','Neymar','Claudiney'),
('Ciência da Computação','Graduação','3','Brendon','Kaique'),
('Economia','Graduação','2','Gilson','Leonardo'),
('Administração','Técnico','4','Sabrina','Bruno'),
('Engenharia de Software','Graduação','5','Gisele','Virgínia');

insert into Professor (
Nome_Professor,
CPF_Professor,
Codigo_Departamento,
Telefone_Professor,
Disciplina
)
values
('Claudiney','21451658778','1','12996545107',4),
('Neymar','36554521441','1','11996322658',1),
('Sabrina','41225158774','4','11995458763',2),
('Alan','85445514228','5','12995488620',3),
('Fabiana','45865112441','3','11996545220',5);

insert into Disciplina (
Nome_Disciplina,
Descricao_Disciplina,
Numero_Creditos,
Codigo_Departamento,
Aluno,
Professor,
Oferta
)
values
('Banco de Dados','Ensina como fazer um banco de dados','02',1,5,2,1),
('Finanças','Contas a pagar, tributos e impostos, investimentos e etc','03',4,3,3,2),
('Geometria Analítica','Estudo de geometria por meio de um sistema de coordenadas','04',1,2,4,3),
('Arquitetura de Software','Ensina a identificar requisitos que afetem a estrutura de software','01',5,4,1,4),
('Economia Política','Ensino relacionado à situação econômica de um país','02',2,1,5,1);

insert into Oferta (
Professor,
Horario_Entrada,
Horario_Saida, 
Disciplina,
Aluno
)
Values
(2,'070000','150000',1,3),
(1,'090000','160000',4,2),
(5,'110000','153000',5,5),
(3,'120000','184500',2,4),
(4,'080000','140000',3,1);
 
show tables;

select 
	 Nome_Disciplina, Descricao_Disciplina
from Disciplina;

select
	 Nome_Aluno, CPF_Aluno
from Aluno;

select
	 Nome_Professor, CPF_Professor
from
	 Professor
where
     Matricula_Professor = 4;

select * from Oferta;

update 
	Aluno
set
    Nome_Aluno = 'Maria Clara Batista'
where
	Numero_de_Matricula = 1;
    




