create database Empregado;
use Empregado;

create table Empregado (
CODEmpregado int auto_increment primary key,
NomeEmpregado varchar (25) not null,
SobrenomeEmpregado varchar (40) not null,
Departamento int references Departamento (CODIGODepto),
TelefoneEmpregado varchar (11),
DataAdmissaoEmpregado datetime,
CargoEmpregado varchar (20) not null,
FormacaoEmpregado varchar (30),
sexoEmpregado varchar (9),
DataNascimentoEmpregado datetime);

create table Departamento (
CODIGODepto int auto_increment primary key,
Nome varchar (50),
NomeGerente int references Empregado(CODEmpregado));
 
create table Projeto (
CODIGOProj int auto_increment primary key,
Nome varchar (50) not null,
Responsável varchar (40) not null,
NumeroEquipe varchar (10),
Departamento int references Departamento(CODIGODepto),
Cliente int references Cliente(CODCliente));

create table Departamento (
CODIGODepto int auto_increment primary key,
NomeDepartamento varchar (50),
NomeGerente int references Empregado(CODEmpregado));
 
create table Projeto (
CODIGOProj int auto_increment primary key,
NomeProjeto varchar (50) not null,
ResponsavelProjeto varchar (40) not null,
NumeroEquipeProjeto varchar (10),
Cliente int references Cliente(CODCliente),
DataInicioProjeto datetime,
DataFimProjeto datetime);

create table Cliente ( 
CODCliente int auto_increment primary key,
NomeCliente varchar (20) not null,
SobrenomeCliente varchar (40) not null,
EnderecoCliente varchar (50),
CidadeCliente varchar (40),
EstadoCliente varchar (2),
CEPCliente varchar (8),
RGCliente varchar (14),
CPFCliente varchar (11),
DataNascimentoCliente datetime,
Projeto int references Projeto(CODIGOProj),
TelefoneCliente varchar (11),
SexoCliente varchar (9),
EmailCliente varchar (40));

alter table Empregado add NomeGerente varchar (15);
insert into Empregado (
CODEmpregado,
NomeEmpregado,
SobrenomeEmpregado,
DepartamentoEmpregado, 
TelefoneEmpregado, 
DataAdmissaoEmpregado,
CargoEmpregado,
FormacaoEmpregado,
SexoEmpregado,
DataNascimentoEmpregado,
NomeGerente)
Values 
('01', 'Mario', 'Almeida', 'Recursos Humanos', '12996849302', '20090703', 'Supervisor', 'Administração','Masculino', '19990910','Gustavo'),
('02','Maria', 'Aparecida', 'Operacional', '11988769414', '20100901', 'Auxiliar de Manutenção', 'Administração','Feminino', '19970221','Daniel'),
('03','Julia', 'Gomes', 'Marketing', '129856889123', '20170509', 'Diretora Administrativa', 'Economia','Feminino', '19891223','Hugo'),
('04','João Lucas', 'Nunes', 'Financeiro', '11435271881', '20030817', '', 'Contabilidade','Masculino', '19870131','Ferdinando'),
('05','Gabriel', 'Barbosa', 'Comercial', '12996849398', '20050912', 'Estagiário', 'Gestão Financeira','Masculino', '19791011','Joaquim');
 
insert into Departamento (
CODIGODepto,
NomeDepartamento,
NomeGerenteProjeto)
Values 
('01', 'Financeiro', 'Amala Garcia da Silva'),
('02','Marketing', 'Gustav Juc Manchester'),
('03','Recursos Humanos', 'Henrique Nunes Castro'),
('04','Operacional', 'Ariana Brondy Habla'),
('05','Comercial', 'Marcelo Rodrigues');

insert into Projeto (
CODIGOProj,
NomeProjeto, 
ResponsavelProjeto,
NumeroEquipeProjeto,
ClienteProjeto,
DataInicioProjeto,
DataFimProjeto)
Values 
('1', 'Carros Elétricos', 'Amala Garcia da Silva','equipe 21', 'Julio Almeida', '202210101', '20230101'),
('2', 'Araras', 'Ana Luana','equipe 20', 'Kaique Junior', '202212101', '202305010'),
('3', 'Computadores Móveis', 'Fabio Barbosa Lima','equipe 19', 'Benedito Brito', '202210101', '20230101'),
('4', 'Meio Ambiente', 'Nicolas Venâncio','equipe 17', 'Samantha Cardoso', '20221101', '20230601'),
('5', 'Casa Branca', 'Gabriela Monique','equipe 15', 'Leonard Pierre', '20221210', '20230701');

insert into Cliente (
CODCliente,
NomeCliente,
SobrenomeCliente,
EnderecoCliente,
CidadeCliente,
EstadoCliente,
CEPCliente,
RGCliente,
CPFCliente,
DataNascimentoCliente,
Projeto,
TelefoneCliente,
SexoCliente,
EmailCliente)
values 
('1', 'Julia', 'Martins', 'Rua Sapos Crocantes', 'SP', '12231451', '1978659402', '45276143552','20010230', 'Meio ambiente','12996754738', 'Feminino', 'juliama@gmail.com'),
('2', 'Vinícius', 'Dongo', 'Rua Riacho Branco', 'RS', '13831841', '1212247900', '9895643728','20000128', 'Araras','2541536985', 'Masculino', 'vinicius@gmail.com'),
('3', 'Luís', 'Silva', 'Rua Giovanne Leite', 'RJ', '13212344', '5852123698', '6574893242','20020313', 'Computadores Móveis','5524136985', 'Masculino', 'luis@gmail.com'),
('4', 'Paulo', 'Lobo', 'Rua Hugo Mil', 'RR', '12768999', '3223655485', '4529831422','19990210', 'Casa Branca','13625142039', 'Masculino', 'paulo@gmail.com'),
('5', 'Sabrina', 'Monticeli', 'Rua Ana Braga', 'SP', '10988767', '3652201148', '4152897631','19880802', 'Carros Elétricos','11254879655', 'Feminino', 'sabri@gmail.com');

select * from Cliente;

select
     NomeEmpregado, SobrenomeEmpregado, TelefoneEmpregado
from Empregado;

select
    NomeCliente, SexoCliente
from Cliente;

select 
     NomeEmpregado, NomeGerente
from Empregado;

select
     ResponsavelProjeto, NumeroEquipeProjeto, DataFimProjeto
from Projeto;

update
     Empregado
set
     CODEmpregado= '09',
     NomeEmpregado= 'Maria Clara',
     SobrenomeEmpregado= 'Batista Aparecido',
     Departamento= 'Financeiro',
     TelefoneEmpregado= '12996237219',
     DataAdmissaoEmpregado= '20220203',
     CargoEmpregado= 'Supervisor',
     FormacaoEmpregado= 'Administração',
     SexoEmpregado= 'Feminino',
     DataNascimentoEmpregado= '20061110',
     NomeGerente='Neymar'
where
     CODEmpregado='3';
     
select * from Cliente;
update
	Cliente
set
    CodigoCliente='6'
where
    CodigoCliente='1';
    
update
	Cliente
set
    CodigoCliente='7'
where
    CodigoCliente='2';

update
	Cliente
set
    CodigoCliente='8'
where
    CodigoCliente='3';

update
	Cliente
set
    CodigoCliente='9'
where
    CodigoCliente='4';
    
update
	Cliente
set
    CodigoCliente='10'
where
    CodigoCliente='5';


    


 
 
     