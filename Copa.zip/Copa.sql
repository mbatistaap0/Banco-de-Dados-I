create database Copa_do_Mundo;
use Copa_do_Mundo;

create table País(
CodP int auto_increment primary key,
NomeP varchar (30)
);

insert into País(
NomeP)
Values
('Alemanha'),
('Arábia Saudita'),
('Argentina'),
('Austrália'),
('Bélgica'),
('Brasil'),
('Camarões'),
('Canadá'),
('Catar'),
('Coreia do Sul'),
('Costa Rica'),
('Croácia'),
('Dinamarca'),
('Equador'),
('Espanha'),
('Estados Unidos'),
('França'),
('Gana'),
('Holanda'),
('Inglaterra'),
('Irã'),
('Japão'),
('Marrocos'),
('México'),
('País de Gales'),
('Polônia'),
('Portugal'),
('Senegal'),
('Sérvia'),
('Suiça'),
('Tunísia'),
('Uruguai');

create table Jogadores(
CodJ int auto_increment primary key,
NomeJ varchar (40),
Posição varchar (20),
CodP int references País (CodP));

insert into Jogadores(
NomeJ,
Posição,
CodP)
Values
('Alisson','Goleiro', 25),
('Valencia','Atacante', 14),
('Lionel Messi','Atacante', 3),
('Nick Pope','Goleiro', 20),
('Axel Disasi','Zagueiro', 17);

create table Grupos(
CodGrupos int auto_increment primary key,
NomeGrupos varchar (7),
CodP1 int references País (CodP),
CodP2 int references País (CodP)
);

insert into Grupos(
NomeGrupos,
CodP1,
CodP2)
Values
('A', 9, 14),
('B', 20, 21),
('C', 3, 2),
('D', 13, 31),
('E', 1, 22);

create table Jogos(
CodJogo int auto_increment primary key,
CodGrupos int references Grupos (CodGrupos),
Horário time,
Dia datetime,
CodP1 int references País (CodP),
CodP2 int references País (CodP)
);

insert into Jogos(
CodGrupos,
Horário,
Dia,
CodP1,
CodP2)
Values
(1,'130000','221120', 9, 14),
(2,'100000','221121', 20, 21),
(3,'070000','221122', 3, 2),
(4,'100000','221122', 13, 31),
(5,'160000','221123', 1, 22);

create table Árbitros(
CodÁrbitro int auto_increment primary key,
NomeÁrbitro varchar (40),
CodP int references País (CodP)
);

insert into Árbitros(
NomeÁrbitro,
CodP)
Values
('Alireza Faghani','21'),
('Yoshimi Yamashita','22'),
('Antonio Mateu','15'),
('Mauro Vigliano','3'),
('César Ramos','24');

create table Estádio(
CodEstádio int auto_increment primary key,
NomeEstádio varchar (40),
CodJogo int references Jogos (CodJogo),
CodP int references País (CodP)
);

insert into Estádio(
NomeEstádio,
CodJogo,
CodP)
Values
('Al Bayt Stadium','1','9'),
('Khalifa Internacional','2','9'),
('Lusail','3','9'),
('Khalifa Internacional','5','9'),
('Education City','4', '9');
