create database Livraria;
use Livraria;

create table Cliente (
CodigoCliente int auto_increment primary key,
TelefoneCliente varchar (11) not null,
EndereçoCliente varchar (30),
CPFCliente varchar (11),
CNPJCliente varchar (14),
TipoCliente varchar (20)
);

create table Livro (
ISBNLivro int auto_increment primary key,
QtdeLivro varchar (5) not null,
AssuntoLivro varchar (100),
AutorLivro varchar (20),
CodigoEditora int references Editora (CodigoEditora)
);

create table Editora (
CodigoEditora int auto_increment primary key,
EndereçoEditora varchar (20) not null,
TelefoneEditora varchar (100),
GerenteEditora varchar (20),
ISBNLivro int references Livro (ISBN)
);

create table Cliente_Compra_Livro (
CodigoCliente int references Cliente (CodigoCliente),
ISBNLivro int references Livro (ISBNLivro),
CodigoEditora int references Editora (CodigoEditora)
);

alter table Cliente add NomeCliente varchar (30);
alter table Livro add NomeLivro varchar (110);

insert into Cliente (
TelefoneCliente,
EndereçoCliente,
CPFCliente,
CNPJCliente,
TipoCliente,
NomeCliente
)
Values
('12996237219', 'Rua Pico do Bugil', '36532635114', '36698741145225', 'Aluno', 'Maria Clara Batista'),
('12366587412', 'Rua Martim de Sá', '25486392514', '69854124475154', 'Professor', 'Leonardo Santos'),
('12887445142', 'Rua Lindon Marquês', '36525447811', '39254487511203', 'Estagiário', 'Claudio Bragantino'),
('12336985201', 'Rua Pierre de Bruyne', '36559874120', '32014587963201', 'Aluno', 'Marco Gael Junior'),
('12336520147', 'Rua Jucelin Hugo', '33654789621', '45874218925', 'Aluno', 'Cléber deMarco Filho');

insert into Livro (
QtdeLivro,
AssuntoLivro,
AutorLivro,
CodigoEditora,
NomeLivro
)
values
('1', 'Ficção', 'J. R. R. Tolkien',1,'O senhor dos anéis'),
('1', 'Fantasia', 'C.S. Lewis',2,'As Crônicas de Nárnia'),
('2', 'Fantasia', 'J,K Rowling',3,'Harry Potter e a Pedra Filosofal'),
('1', 'Romance', 'Colleen Hoover',4,'É assim que acaba'),
('2', 'Romance', 'Adam Silvera',5,'Os dois morrem no final');

insert into Editora (
EndereçoEditora,
TelefoneEditora,
GerenteEditora
)
values
('Rua Janete Cardoso', '12996478544', 'Gustavo Lisboa'),
('Rua Limoeiro Grande', '12115987412', 'Fábio Hugo'),
('Rua Bruno Gomes', '12336985547', 'Lewa Robinson'),
('Rua Abacaxi Furado', '12336548745', 'Caio Barbosa'),
('Rua Agulhas Negras', '12996201557', 'Poliane Silveira');

insert into Cliente_Compra_Livro (
CodigoCliente,
ISBNLivro
)
values
(1,1),
(2,2),
(3,3),
(4,4),
(5,5);

show tables;

select 
      CPFCliente, TipoCliente
from Cliente;

select
     CodigoEditora, GerenteEditora
from Editora;

update 
     Editora
set
    EndereçoEditora = 'Av. Andrômeda, 1520',
	TelefoneEditora= '12123356789'
WHERE
	CodigoEditora = 5;
    
select*from Editora
    




    






